//var main = function (input) {
//var myOutputValue = 'hello world';
//return myOutputValue;
//};

// What is the input going to be?
// What should the output be?
// How will the computer's option be randomly generated?
// How many different cases are there?

var main = function (input) {
  //if (gameInput == "1" || gameInput == "2" || gameInput == "3") {
  var myOutputValue = `Testing`;
  return myOutputValue;
};
