var followArraysMain = function (input) {
  // Attempt the Follow Along exercise from the Arrays module below with followArraysMain as the main function.
  var myOutputValue = 'hello world';
  return myOutputValue;
};

var followArraysLoopsMain = function (input) {
  // Attempt the Follow Along exercise from the Looping Over An Array module below with followArraysLoopsMain as the main function.
  var myOutputValue = 'hello world';
  return myOutputValue;
};
